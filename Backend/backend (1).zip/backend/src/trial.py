import sys

# 첫 번째 명령줄 인수는 스크립트 자체이므로 두 번째 인수부터가 입력 데이터
inputData =int(sys.argv[1])

result =  inputData+3

print(result)
